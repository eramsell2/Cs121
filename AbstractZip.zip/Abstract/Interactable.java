package WeekTen.interfaces;

public interface Interactable {
    String combineLogin();
}
