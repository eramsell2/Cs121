package WeekEleven.BigOActivity;

public class Test {
    public static void main(String[] args) {
        BigO newBigO = new BigO();
        newBigO.printOnce(8);
        newBigO.printNTimes("Hi", 8);
        newBigO.printNSquaredTimes(8, "hey");
    }
}
