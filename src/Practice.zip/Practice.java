import javax.xml.namespace.QName;

public class Practice {
    public static void main(String[] args) {

    //comment One Here
        /*comment two */


        System.out.println("my name is ethan");
        String name = "ethan";
        System.out.printf("This person's name is : %s      They are cool.", name);

        System.out.print("hello");
        System.out.print("world");


    }

}


