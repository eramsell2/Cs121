package WeekSix.ClassActivity;

public class Game {
    String console, genre, color;
    Game(){
        this.console = "PS5";
        this.genre = "FPS";
        this.color = "Blue";
    }
    Game(String console, String genre, String color){
        this.console = console;
        this.genre = genre;
        this.color = color;
    }
}
