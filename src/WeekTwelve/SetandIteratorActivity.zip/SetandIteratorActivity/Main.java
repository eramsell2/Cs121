package WeekTwelve.SetandIteratorActivity;

public class Main {
    public static void main(String[] args) {
        MovieCollectionSet movieCollection = new MovieCollectionSet();
        movieCollection.addMovies();
        movieCollection.displayMovies();
    }
}
