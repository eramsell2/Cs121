package WeekEleven;

public class RecursionTest {
    public static void main(String[] args) {
        recursion newRecursion = new recursion();
        newRecursion.countDown(10);
        newRecursion.alphaBackwards('b');
    }
}
